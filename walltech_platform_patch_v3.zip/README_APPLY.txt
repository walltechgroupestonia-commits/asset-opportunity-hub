WALLTECH PLATFORM PATCH V3

File:
- src/components/walltech/OperatingSystem.tsx
- src/routes/index.tsx

Applicazione:
1. creare OperatingSystem.tsx nel percorso indicato;
2. sostituire index.tsx;
3. commit su main;
4. verificare Preview Lovable.
